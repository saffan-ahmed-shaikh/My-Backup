import { Request, Response } from "express";
import { User } from "../models/user";

export const buildUser = async (req: Request, res: Response) => {
  const jane = User.build({ firstName: "shubham", lastName: "gill" });
  console.log(jane instanceof User); // true
  await jane.save();
  console.log("Jane was saved to the database!");
  res.status(200).json(jane.toJSON());
};

export const getUsers = async (req: Request, res: Response) => {
  const data = await User.findAll();
  res.status(200).json(data);
};

export const getIdUser = async (req: Request, res: Response) => {
  const data = await User.findOne({ where: { id: req.params.id } });
  res.status(200).json(data);
};

export const addUsers = async (req: Request, res: Response) => {
  let data;
  if (req.body.length > 1) {
    data = await User.bulkCreate(req.body);
  } else {
    data = await User.create(req.body);
  }
  res.status(200).json(data);
};

export const deleteUser = async (req: Request, res: Response) => {
  const data = await User.destroy({ where: { id: req.params.id } });
  res.status(200).json(data);
};

export const patchUser = async (req: Request, res: Response) => {
  const data = await User.update(req.body, { where: { id: req.params.id } });
  res.status(200).json(data);
};

export  const finders = async (req: Request, res: Response) => {
  const [user, created] = await User.findOrCreate({
    where: { firstName: "sahil" },
    defaults: {
      lastName: "sayyed", 
    },
  });
  res.status(200).json({ data: user, created: created });
}; 

export const getVirtualUsers = async (req: Request, res: Response) => {
  const data = await User.findAll();
  res.status(200).json({ data: data });
};
