import express, { Request, Response, Application } from "express";
require("./models");
const bodyParser = require("body-parser");
import {
  buildUser,
  getUsers,
  getIdUser,
  addUsers,
  deleteUser,
  patchUser,
  finders,
  getVirtualUsers,
} from "./controllers/UserController";
const app: Application = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

app.get("/", (req: Request, res: Response) => {
  res.send("Hello Typescript with Node.js!");
});

app.get("/buildUser", buildUser);

app.get("/users", getUsers);
app.get("/users/:id", getIdUser);

app.post("/users", addUsers);

app.delete("/users/:id", deleteUser);

app.patch("/users/:id", patchUser);

app.get("/finders", finders);

app.get("/virtual", getVirtualUsers);

// User.sync({ force: true });
// Contact.sync({ force: true });
app.listen(PORT, () => {
  console.log(`Server Running here 👉 https://localhost:${PORT}`);
});
