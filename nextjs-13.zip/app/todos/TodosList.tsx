import Link from "next/link";
import React from "react";
type Todo = {
  userId: number;
  id: number;
  title: string;
  completed: boolean;
};

const fetchTodos = async () => {
  const res = await fetch("https://jsonplaceholder.typicode.com/todos/");
  const todos: Todo[] = await res.json();
  return todos;
};

export default async function TodosList() {
  const todos = await fetchTodos();
  return (
    <>
      {todos.map((item, i) => (
        <p key={i}>
          <Link href={`/todos/${item.id}`}>Todo: {item.id}</Link>
        </p>
      ))}
    </>
  );
}
