import React from "react";
import TodoList from "./TodosList";
export default function Todos() {
  return (
    <div>
      {/*@ts-ignore*/}
      <TodoList />
    </div>
  );
}
