/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/layout",{

/***/ "(app-client)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=E%3A%5CUI%20Training%5CNext%20Js%2013%5Cnextjs-13%5Cstyles%5Cglobals.css&server=false!":
/*!****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=E%3A%5CUI%20Training%5CNext%20Js%2013%5Cnextjs-13%5Cstyles%5Cglobals.css&server=false! ***!
  \****************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("(() => __webpack_require__.e(/*! import() */ \"_app-client_styles_globals_css\").then(__webpack_require__.bind(__webpack_require__, /*! ./styles/globals.css */ \"(app-client)/./styles/globals.css\")))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1jbGllbnQpLy4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9idWlsZC93ZWJwYWNrL2xvYWRlcnMvbmV4dC1mbGlnaHQtY2xpZW50LWVudHJ5LWxvYWRlci5qcz9tb2R1bGVzPUUlM0ElNUNVSSUyMFRyYWluaW5nJTVDTmV4dCUyMEpzJTIwMTMlNUNuZXh0anMtMTMlNUNzdHlsZXMlNUNnbG9iYWxzLmNzcyZzZXJ2ZXI9ZmFsc2UhLmpzIiwibWFwcGluZ3MiOiJBQUFBLE9BQU8sNExBQStGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8/OTEwNCJdLCJzb3VyY2VzQ29udGVudCI6WyIoKCkgPT4gaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImxhenlcIiAqLyBcIkU6XFxcXFVJIFRyYWluaW5nXFxcXE5leHQgSnMgMTNcXFxcbmV4dGpzLTEzXFxcXHN0eWxlc1xcXFxnbG9iYWxzLmNzc1wiKSkiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(app-client)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=E%3A%5CUI%20Training%5CNext%20Js%2013%5Cnextjs-13%5Cstyles%5Cglobals.css&server=false!\n"));

/***/ })

});