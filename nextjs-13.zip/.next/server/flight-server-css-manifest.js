self.__RSC_CSS_MANIFEST={
  "__entry_css_mods__": {
    "E:\\UI Training\\Next Js 13\\nextjs-13\\app\\todos\\page": [
      "E:\\UI Training\\Next Js 13\\nextjs-13\\styles\\globals.css"
    ],
    "E:\\UI Training\\Next Js 13\\nextjs-13\\app\\todos\\[id]\\page": [
      "E:\\UI Training\\Next Js 13\\nextjs-13\\styles\\globals.css"
    ]
  },
  "E:\\UI Training\\Next Js 13\\nextjs-13\\app\\layout.tsx": [
    "E:\\UI Training\\Next Js 13\\nextjs-13\\styles\\globals.css"
  ]
}